#include "Systems/InputsManager.h"

bool InputsManager::endGame_ = false;
