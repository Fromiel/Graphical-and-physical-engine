#ifndef INCLUDEGLFW_H
#define INCLUDEGLFW_H

#define GLFW_INCLUDE_NONE
#include <GLFW/glfw3.h>

#endif