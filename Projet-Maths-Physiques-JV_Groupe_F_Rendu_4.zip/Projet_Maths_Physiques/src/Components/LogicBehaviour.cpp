#include "Components/LogicBehaviour.h"


LogicBehaviour::LogicBehaviour(Entity entity) : entity_(entity) { }